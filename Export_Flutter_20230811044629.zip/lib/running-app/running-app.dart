import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // runningapp9ny (9:690)
        width: double.infinity,
        height: 836*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Stack(
          children: [
            Positioned(
              // rectangle16c4H (9:691)
              left: 0*fem,
              top: 629*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 207*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff272244),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle15h5j (9:692)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 741*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff0b0430),
                      borderRadius: BorderRadius.only (
                        bottomRight: Radius.circular(30*fem),
                        bottomLeft: Radius.circular(30*fem),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // vector2NxZ (9:693)
              left: 68*fem,
              top: 777.5*fem,
              child: Align(
                child: SizedBox(
                  width: 18*fem,
                  height: 19.5*fem,
                  child: Image.asset(
                    'assets/running-app/images/vector-2.png',
                    width: 18*fem,
                    height: 19.5*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // group567s (9:694)
              left: 153*fem,
              top: 719*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(27*fem, 22*fem, 21*fem, 22.6*fem),
                width: 70*fem,
                height: 70*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(35*fem),
                ),
                child: Center(
                  // polygon1a33 (9:696)
                  child: SizedBox(
                    width: 22*fem,
                    height: 25.4*fem,
                    child: Image.asset(
                      'assets/running-app/images/polygon-1.png',
                      width: 22*fem,
                      height: 25.4*fem,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group46n5 (9:697)
              left: 288.0170898438*fem,
              top: 779*fem,
              child: Align(
                child: SizedBox(
                  width: 18.98*fem,
                  height: 19*fem,
                  child: Image.asset(
                    'assets/running-app/images/group-4.png',
                    width: 18.98*fem,
                    height: 19*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle17biq (9:700)
              left: 32*fem,
              top: 137*fem,
              child: Align(
                child: SizedBox(
                  width: 312*fem,
                  height: 124*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      color: Color(0xff272244),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group2HrZ (9:701)
              left: 32*fem,
              top: 137*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 312*fem,
                  height: 131*fem,
                  child: Stack(
                    children: [
                      Positioned(
                        // maskgroupn2d (9:702)
                        left: 0*fem,
                        top: 0*fem,
                        child: Align(
                          child: SizedBox(
                            width: 312*fem,
                            height: 124*fem,
                            child: Image.asset(
                              'assets/running-app/images/mask-group.png',
                              width: 312*fem,
                              height: 124*fem,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // vector1TuT (9:722)
                        left: 150*fem,
                        top: 28*fem,
                        child: Align(
                          child: SizedBox(
                            width: 77*fem,
                            height: 63*fem,
                            child: Image.asset(
                              'assets/running-app/images/vector-1.png',
                              width: 77*fem,
                              height: 63*fem,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // group1AJ5 (9:723)
                        left: 29*fem,
                        top: 31*fem,
                        child: Container(
                          width: 273*fem,
                          height: 100*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // autogroupq4fbFqK (K5eNJmeFanwCdyyGBPQ4Fb)
                                margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 92*fem, 0*fem),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      // todayrun1T7 (9:724)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                      child: Text(
                                        'Today Run',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 15*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.1725*ffem/fem,
                                          letterSpacing: 1.2*fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                    Text(
                                      // kmV7P (9:725)
                                      '24 KM',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              TextButton(
                                // component61rR (33:294)
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  width: 100*fem,
                                  height: 100*fem,
                                  child: Image.asset(
                                    'assets/running-app/images/component-6.png',
                                    width: 100*fem,
                                    height: 100*fem,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              // group3K6R (9:726)
              left: 127*fem,
              top: 43*fem,
              child: Container(
                width: 121*fem,
                height: 44*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // goodmorning32R (9:727)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                      child: Text(
                        'Good Morning',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 16*ffem,
                          fontWeight: FontWeight.w300,
                          height: 1.1725*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                    Container(
                      // autogroupgi5fwtV (K5eNYgQjyRgCivqFMFgi5F)
                      margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 4*fem, 0*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // draxatelier5zh (9:728)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                            child: Text(
                              'Drax Atelier',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w700,
                                height: 1.1725*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                          Container(
                            // chevrondownCpR (9:729)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                            width: 8*fem,
                            height: 4*fem,
                            child: Image.asset(
                              'assets/running-app/images/chevron-down.png',
                              width: 8*fem,
                              height: 4*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // bellinm (9:748)
              left: 323*fem,
              top: 55*fem,
              child: Align(
                child: SizedBox(
                  width: 18*fem,
                  height: 20*fem,
                  child: Image.asset(
                    'assets/running-app/images/bell.png',
                    width: 18*fem,
                    height: 20*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle15SCy (9:731)
              left: 32*fem,
              top: 296*fem,
              child: Align(
                child: SizedBox(
                  width: 312*fem,
                  height: 373*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      color: Color(0xff272244),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // summarry9dB (9:732)
              left: 67*fem,
              top: 324*fem,
              child: Align(
                child: SizedBox(
                  width: 80*fem,
                  height: 18*fem,
                  child: Text(
                    'Summarry',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.1725*ffem/fem,
                      letterSpacing: 1.2*fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group9eiM (9:733)
              left: 67*fem,
              top: 364*fem,
              child: Container(
                width: 243*fem,
                height: 77*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // BCV (9:735)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                      child: Text(
                        '298',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 65*ffem,
                          fontWeight: FontWeight.w700,
                          height: 1.1725*ffem/fem,
                          letterSpacing: 1.95*fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                    Container(
                      // kcalcaloriesUhP (9:734)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                      child: Text(
                        'Kcal - Calories',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 15*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.1725*ffem/fem,
                          letterSpacing: 1.2*fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group8b1K (9:736)
              left: 66*fem,
              top: 597*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 6*fem, 0*fem),
                width: 244*fem,
                height: 38*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogroupwahwhKF (K5eNmvXg6PVk4a8d8mWAhw)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 34*fem, 0*fem),
                      width: 32*fem,
                      height: 32*fem,
                      child: Image.asset(
                        'assets/running-app/images/auto-group-wahw.png',
                        width: 32*fem,
                        height: 32*fem,
                      ),
                    ),
                    Container(
                      // group7cx1 (9:737)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 38*fem, 0*fem),
                      height: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(
                            // Mub (9:738)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                            child: Text(
                              '2,504',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 12*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1725*ffem/fem,
                                letterSpacing: 0.96*fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                          Text(
                            // stepsH2Z (9:739)
                            'Steps',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              letterSpacing: 0.96*fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // group6cqX (9:740)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 35*fem, 0*fem),
                      height: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // kmYjB (9:742)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                            child: Text(
                              '78,90 Km',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 12*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1725*ffem/fem,
                                letterSpacing: 0.96*fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                          Text(
                            // distance4Sd (9:741)
                            'Distance',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              letterSpacing: 0.96*fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // chevrondownPzh (9:743)
                      width: 4*fem,
                      height: 8*fem,
                      child: Image.asset(
                        'assets/running-app/images/chevron-down-Wam.png',
                        width: 4*fem,
                        height: 8*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // component28hP (9:1610)
              left: 32*fem,
              top: 451*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 134*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/running-app/images/component-2.png',
                      width: 50*fem,
                      height: 134*fem,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}