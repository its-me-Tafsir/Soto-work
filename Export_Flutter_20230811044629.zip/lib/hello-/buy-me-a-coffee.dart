import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 1366;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // buymeacoffeeLYq (43:17)
        padding: EdgeInsets.fromLTRB(50*fem, 88.5*fem, 0*fem, 91*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // group2096fLD (43:18)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 51*fem, 0*fem),
              width: 530*fem,
              height: 588.5*fem,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // autogroupjj4dBZT (K5eQ98kgxnZwKC6Q5Djj4D)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 43.63*fem),
                    width: 526*fem,
                    height: 454.88*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // ihopeeveryoneissafeandsoundide (43:19)
                          left: 0*fem,
                          top: 48*fem,
                          child: Align(
                            child: SizedBox(
                              width: 526*fem,
                              height: 393*fem,
                              child: Text(
                                'I hope everyone is safe and sound.\nI designed different type of lending pages, application. it can help others to develop more ideas from this. I keep it simple and minimal. It can also help you find different options in exploring and improving your skills.\n\n\n\nI am available for new projects. I hope you show me your support 😄\n\nI wish you luck,\nDrax❤️',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.8879998922*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // helloPow (43:20)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 149*fem,
                              height: 61*fem,
                              child: Text(
                                'Hello 👋',
                                style: SafeGoogleFont (
                                  'Gilroy',
                                  fontSize: 47.7488136292*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.2575*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // vectorU4h (43:25)
                          left: 256*fem,
                          top: 430.125*fem,
                          child: Align(
                            child: SizedBox(
                              width: 18*fem,
                              height: 24.75*fem,
                              child: Image.asset(
                                'assets/hello-/images/vector.png',
                                width: 18*fem,
                                height: 24.75*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group2095nr5 (43:21)
                    width: double.infinity,
                    height: 90*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(100*fem),
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          // frame8f3 (43:22)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 530*fem,
                              height: 90*fem,
                              child: Image.asset(
                                'assets/hello-/images/frame.png',
                                width: 530*fem,
                                height: 90*fem,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // buymeacoffeer5F (43:24)
                          left: 161*fem,
                          top: 25*fem,
                          child: Align(
                            child: SizedBox(
                              width: 208*fem,
                              height: 41*fem,
                              child: Text(
                                'Buy me a Coffee',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 25*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.6379998779*ffem/fem,
                                  decoration: TextDecoration.underline,
                                  color: Color(0xffffffff),
                                  decorationColor: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // frameLWD (43:26)
              margin: EdgeInsets.fromLTRB(0*fem, 2.33*fem, 0*fem, 0*fem),
              width: 943.27*fem,
              height: 544.96*fem,
              child: Image.asset(
                'assets/hello-/images/frame-WHf.png',
                width: 943.27*fem,
                height: 544.96*fem,
              ),
            ),
          ],
        ),
      ),
          );
  }
}